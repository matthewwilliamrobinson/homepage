<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphnvd3}default-bootstrap>graphnvd3_a9f70dff230e6fc8e878043486e6cddf'] = 'NVD3 Charts';
