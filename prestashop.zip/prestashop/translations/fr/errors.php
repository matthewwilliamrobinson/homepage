<?php
	global $_ERRORS;
	$_ERRORS = array();
?>