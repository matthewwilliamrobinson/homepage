<?php
	$tabs = array();
	return $tabs;
?>